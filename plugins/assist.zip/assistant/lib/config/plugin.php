<?php
return array (
    'name' => 'Assistant bot',
    'img' => 'img/assistant16.png',
    'version' => '1.0.2',
    'vendor' => '964801',
    'frontend' => true,
    'telegram_settings' => true,
    'handlers' =>
        array (
        ),
);
