<?php

return array(
    'php' => array(
        'strict' => true,
        'version' => '>=7.4.0',
    ),
    'app.telegram' => array(
        'version' => '>=2.1.0',
        'strict' => true
    ),
);