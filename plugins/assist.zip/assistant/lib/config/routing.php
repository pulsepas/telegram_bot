<?php
return array (
  'assistant/bot' => 'frontend/bot',
);
